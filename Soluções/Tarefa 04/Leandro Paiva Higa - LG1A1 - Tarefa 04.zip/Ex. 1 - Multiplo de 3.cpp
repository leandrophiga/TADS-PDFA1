#include <stdio.h>

int main ()
{
    for (int i = 1; i * 3 <= 100; i++)
        printf("%i\n", i * 3);

    return 0;
}

