#include <stdio.h>

int main ()
{
    for (int i = 15; i <= 200; i++)
    {
        printf("%i\n", i * i);
    }

    return 0;
}
